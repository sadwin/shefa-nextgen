'use client';
import { useState } from 'react';

export default function FlyerPreview({ t }) {
  const [bizName, setBizName] = useState('');
  const displayName = bizName || 'Your Business Name';

  return (
    <div className="w-full bg-slate-900/40 border border-slate-800 rounded-3xl p-8 backdrop-blur-sm">
      <div className="grid md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-5 text-left space-y-4">
          <h2 className="text-2xl font-bold text-white">{t.flyer_title}</h2>
          <p className="text-sm text-slate-400">{t.flyer_desc}</p>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{t.flyer_label}</label>
            <input 
              type="text" 
              maxLength={28}
              value={bizName}
              onChange={(e) => setBizName(e.target.value)}
              placeholder={t.flyer_placeholder} 
              className="w-full bg-slate-950 border border-slate-800 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 transition"
            />
          </div>
          <div className="text-[11px] text-slate-500 leading-relaxed bg-slate-950/50 p-3 rounded-xl border border-slate-900">{t.flyer_how}</div>
        </div>

        <div className="md:col-span-7 flex justify-center">
          <div className="w-[280px] bg-white text-slate-950 rounded-2xl p-6 shadow-[0_20px_50px_rgba(16,185,129,0.1)] border border-slate-200 text-center flex flex-col justify-between aspect-[1/1.4]">
            <div className="space-y-1">
              <p className="text-[10px] font-black tracking-widest text-emerald-600 uppercase">{t.flyer_top}</p>
              <h3 className="text-xl font-extrabold tracking-tight text-slate-900 truncate px-2">{displayName}</h3>
              <p className="text-[11px] font-medium text-slate-500 italic mt-0.5">{t.flyer_sub}</p>
            </div>
            <div className="my-4 flex flex-col items-center justify-center relative">
              <div className="w-36 h-36 bg-slate-50 border-2 border-slate-100 rounded-xl p-2 flex items-center justify-center">
                <svg className="w-full h-full text-slate-900" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 3h4v4H3V3zM3 17h4v4H3v-4zM17 3h4v4h-4V3z" fill="currentColor"/><path d="M17 17h4v4h-4v-4z" stroke="currentColor" strokeWidth="1"/>
                </svg>
              </div>
              <div className="absolute bg-white p-1 rounded-full shadow-md border border-slate-100 text-xs">🟢</div>
            </div>
            <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <p className="text-[10px] font-bold text-slate-800 leading-tight">{t.flyer_bot_nl}</p>
              <p className="text-[9px] text-slate-400 font-medium tracking-wide">{t.flyer_bot_en}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
