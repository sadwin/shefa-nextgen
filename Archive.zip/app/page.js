'use client';
import { useState, useEffect, useRef } from 'react';
import { translations, languages } from './translations';
import Simulator from './Simulator';
import Calculator from './Calculator';
import FlyerPreview from './FlyerPreview';
import BackgroundStars from './BackgroundStars';

export default function Home() {
  const [lang, setLang] = useState('nl');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const t = translations[lang];

  const dropdownRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubscribe = async () => {
    try {
      const res = await fetch('/api/checkout', { method: 'POST' });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
    } catch (err) {
      console.error(err);
    }
  };

  const currentLangObj = languages.find(l => l.code === lang);

  return (
    <div className="bg-[#030712] text-white min-h-screen font-sans antialiased relative overflow-x-hidden">
      
      {/* Премиальный неоновый бэкграунд */}
      <BackgroundStars />

      {/* Шапка */}
      <header className="max-w-6xl mx-auto px-6 py-6 flex justify-between items-center relative z-50">
        <div className="text-xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
          SHEFA<span className="text-white">.NEXTGEN</span>
        </div>
        
        <div ref={dropdownRef} className="relative inline-block text-left">
          <button 
            onClick={() => setDropdownOpen(!dropdownOpen)} 
            className="flex items-center space-x-2 bg-slate-900/80 border border-slate-800 hover:border-slate-700 shadow-xl px-4 py-2 rounded-xl text-sm font-semibold text-slate-200 transition cursor-pointer select-none backdrop-blur-md"
          >
            <span>{currentLangObj.flag}</span>
            <span>{currentLangObj.name}</span>
            <span className="text-xs text-slate-500">▼</span>
          </button>

          {dropdownOpen && (
            <div className="absolute right-0 mt-2 w-40 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-50">
              <div className="py-1">
                {languages.map((l) => (
                  <button 
                    key={l.code} 
                    onClick={() => { setLang(l.code); setDropdownOpen(false); }} 
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 text-left text-sm hover:bg-slate-800 transition cursor-pointer ${
                      lang === l.code ? 'text-emerald-400 bg-slate-800/50 font-bold' : 'text-slate-300'
                    }`}
                  >
                    <span>{l.flag}</span><span>{l.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Главный блок */}
      <main className="max-w-6xl mx-auto px-6 pt-12 pb-24 text-center space-y-24 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 text-left space-y-6">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-[1.15]">
              {t.title1} <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">{t.title2}</span> <br />
              {t.title3}
            </h1>
            <p className="text-base sm:text-lg text-slate-400 max-w-xl leading-relaxed font-medium">{t.desc}</p>
            <div className="pt-2">
              <button 
                onClick={handleSubscribe} 
                className="w-full sm:w-auto bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-black px-8 py-4 rounded-xl text-lg hover:opacity-90 hover:scale-[1.01] active:scale-[0.99] transition shadow-[0_4px_25px_rgba(52,211,153,0.25)] cursor-pointer"
              >
                {t.button}
              </button>
            </div>
            <div className="flex items-center space-x-4 text-xs text-slate-500 font-medium pt-1">
              <span>✓ {t.tag1}</span><span>•</span><span>✓ {t.tag2}</span>
            </div>
          </div>
          <div className="lg:col-span-5"><Simulator /></div>
        </div>

        <FlyerPreview t={t} />
        <Calculator t={t} />

        {/* Киберпанк карточка тарифа */}
        <section className="bg-gradient-to-b from-slate-900/60 to-slate-950/80 border border-emerald-500/20 backdrop-blur-xl rounded-3xl p-8 max-w-md mx-auto text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-emerald-500 text-slate-950 text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-bl-xl">
            {t.price_badge}
          </div>
          <p className="text-xs font-bold uppercase tracking-wider text-emerald-400 mt-2">{t.price_title}</p>
          <div className="mt-4 flex items-baseline justify-center space-x-1">
            <span className="text-5xl font-black text-white">€49</span>
            <span className="text-slate-400 text-sm">/ {t.price_sub}</span>
          </div>
          <button 
            onClick={handleSubscribe} 
            className="w-full mt-8 bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-black py-3.5 rounded-xl transition text-base cursor-pointer shadow-lg hover:opacity-90"
          >
            {t.button}
          </button>
        </section>
      </main>

      <footer className="border-t border-slate-900 py-8 text-center text-xs text-slate-600 font-medium relative z-10">
        © 2026 SHEFA-NEXTGEN. Built for Amsterdam hospitality & services.
      </footer>
    </div>
  );
}
