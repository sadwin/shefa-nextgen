'use client';
import { useState } from 'react';

export default function Calculator({ t }) {
  const [dailyCustomers, setDailyCustomers] = useState(50);

  const monthlyReviews = Math.round(dailyCustomers * 30 * 0.25);
  const capturedNumbers = Math.round(dailyCustomers * 30 * 0.40);

  return (
    <div className="w-full bg-slate-900/40 border border-slate-800/80 rounded-3xl p-8 backdrop-blur-xl shadow-2xl relative overflow-hidden">
      <div className="text-center max-w-xl mx-auto mb-8">
        <h2 className="text-2xl font-extrabold text-white tracking-tight">{t.calc_title}</h2>
        <p className="text-sm text-slate-400 mt-2">{t.calc_desc}</p>
      </div>
      <div className="grid md:grid-cols-2 gap-8 items-center text-left">
        <div className="space-y-4">
          <div className="flex justify-between items-center text-sm">
            <span className="text-slate-300 font-medium">{t.calc_label}</span>
            <span className="text-emerald-400 font-black text-lg">{dailyCustomers} / day</span>
          </div>
          <input type="range" min="10" max="300" value={dailyCustomers} onChange={(e) => setDailyCustomers(Number(e.target.value))} className="w-full accent-emerald-400 bg-slate-800 h-2 rounded-lg cursor-pointer" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-950/80 border border-emerald-500/20 p-4 rounded-2xl text-center shadow-[0_0_15px_rgba(16,185,129,0.05)]">
            <p className="text-3xl font-black text-emerald-400">+{monthlyReviews}</p>
            <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-bold">{t.calc_res1}</p>
          </div>
          <div className="bg-slate-950/80 border border-teal-500/20 p-4 rounded-2xl text-center shadow-[0_0_15px_rgba(20,184,166,0.05)]">
            <p className="text-3xl font-black text-teal-400">+{capturedNumbers}</p>
            <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-bold">{t.calc_res2}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
