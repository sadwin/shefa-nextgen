'use client';
import { useEffect, useRef } from 'react';

export default function BackgroundStars() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    let animationFrameId;
    let offset = 0; // Смещение для плавной анимации движения сетки

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const draw = () => {
      // Глубокий полуночный фон
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const w = canvas.width;
      const h = canvas.height;

      // 1. Неоновое свечение по углам
      const glowLeft = ctx.createRadialGradient(0, 0, 50, 0, 0, w * 0.6);
      glowLeft.addColorStop(0, 'rgba(16, 185, 129, 0.28)'); 
      glowLeft.addColorStop(1, 'rgba(2, 6, 23, 0)');
      ctx.fillStyle = glowLeft;
      ctx.fillRect(0, 0, w, h);

      const glowRight = ctx.createRadialGradient(w, h, 50, w, h, w * 0.7);
      glowRight.addColorStop(0, 'rgba(20, 184, 166, 0.22)'); 
      glowRight.addColorStop(1, 'rgba(2, 6, 23, 0)');
      ctx.fillStyle = glowRight;
      ctx.fillRect(0, 0, w, h);

      const horizon = h * 0.35; // Линия горизонта
      const gridHeight = h - horizon;

      // 2. Рисуем продольные лучи (Чуть-чуть подкрутили яркость с 0.08 до 0.14)
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.14)'; 
      ctx.lineWidth = 1.5;
      const linesCount = 26;

      for (let i = 0; i <= linesCount; i++) {
        const progress = i / linesCount;
        const xStart = w * -0.6 + w * 2.2 * progress; 
        const xEnd = w * 0.5; 

        ctx.beginPath();
        ctx.moveTo(xStart, h);
        ctx.lineTo(xEnd, horizon);
        ctx.stroke();
      }

      // 3. АНИМИРОВАННЫЕ горизонтальные линии (Яркость на ближнем плане поднята до 0.40)
      offset += 0.0025; // Слегка замедлили полет для большей солидности
      if (offset >= 1) offset = 0;

      const horizLines = 16;
      for (let i = 0; i < horizLines; i++) {
        const lineProgress = (i + offset) / horizLines;
        
        // Экспоненциальное искажение для эффекта 3D
        const ratio = Math.pow(lineProgress, 3);
        const y = h - gridHeight * ratio;

        // Мягко проявили линии у нижнего края экрана, сохранив идеальное затухание к горизонту
        ctx.strokeStyle = `rgba(16, 185, 129, ${ratio * 0.40})`; 
        ctx.lineWidth = 1 + ratio * 2; // Ближние линии стали самую малость плотнее
        
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-0" 
    />
  );
}
